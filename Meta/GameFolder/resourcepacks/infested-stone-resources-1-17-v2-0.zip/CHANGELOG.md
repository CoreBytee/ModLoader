# ChangeLog v2.0
- updated for 1.17 (snap 21w10a)
- added infested deepslate textures.
- added template overlay texture (unused in-game. but is used to apply the overlay to the block texture.)